import logging
import azure.functions as func


app = func.FunctionApp()

@app.event_grid_trigger(arg_name="azeventgrid")
def EventGridTrigger(azeventgrid: func.EventGridEvent):
    logging.info('Python EventGrid trigger processed an event')

    # Extract basic properties from the EventGridEvent object
    event_type = azeventgrid.event_type
    event_time = azeventgrid.event_time.isoformat() if azeventgrid.event_time else None
    blob_name  = azeventgrid.subject  # Typically the blob path or name is in .subject
    
    # Log them (viewable in Application Insights or local console logs)
    logging.info(f"Event type: {event_type}")
    logging.info(f"Blob name:  {blob_name}")
    logging.info(f"Event time: {event_time}")